import java.awt.*;


import java.awt.event.*;

class BiometricMetroRailSystem extends Frame
{
 String msg = "";
 Label ll;
 /*InsertUser insu;
 UpdateUser updu;
 DeleteUser delu;
 InsertVideo insv;
 DeleteVideo delv;
 UpdateVideo updv;
 InsertView insvi;
 UpdateView updvi;
 DeleteView delvi;
 InsertUpload insupl;
 UpdateUpload updupl;
 DeleteUpload delupl;
 InsertAdmin insad;
 UpdateAdmin updad;
 DeleteAdmin delad;*/
 
 public BiometricMetroRailSystem()
 {
ll = new Label();
ll.setAlignment(Label.CENTER);  
ll.setBounds(250,250,250,250);
ll.setText("BIOMETRIC BASED AUTOMATED METRO RAIL SYSTEM!");
add(ll);

// create menu bar and add it to frame
MenuBar mbar = new MenuBar();
setMenuBar(mbar);

// create the menu items and add it to Menu
Menu us = new Menu("Biometric Scanners");
MenuItem item1, item2, item3;
us.add(item1 = new MenuItem("Insert Biomteric Scanners"));
us.add(item2 = new MenuItem("Update Biometric Scanners"));
us.add(item3 = new MenuItem("Delete Biometric Scanners"));
mbar.add(us);  

Menu p = new Menu("Passengers");
MenuItem item4, item5, item6;
p.add(item4 = new MenuItem("Insert Passengers"));
p.add(item5 = new MenuItem("Update Passengers"));
p.add(item6 = new MenuItem("Delete Passengers"));  
mbar.add(p);

Menu s = new Menu("Scans");
MenuItem item7, item8, item9;
s.add(item7 = new MenuItem("Insert scans"));
s.add(item8 = new MenuItem("Update scans"));
s.add(item9 = new MenuItem("Delete scans"));
mbar.add(s);

Menu card = new Menu("Metro Card");
MenuItem item10, item11, item12;
card.add(item10 = new MenuItem("Insert Card"));
card.add(item11 = new MenuItem("Update Card"));
card.add(item12 = new MenuItem("Delete card"));
mbar.add(card);

Menu r = new Menu("Reserves");
MenuItem item13, item14, item15;
r.add(item13 = new MenuItem("Insert reservation"));
r.add(item14 = new MenuItem("Update reservation"));
r.add(item15 = new MenuItem("Delete reservation"));
mbar.add(r);

Menu g = new Menu("Generates");
MenuItem item16, item17, item18;
g.add(item16 = new MenuItem("Insert generate"));
g.add(item17 = new MenuItem("Update generate"));
g.add(item18 = new MenuItem("Delete generate"));
mbar.add(g);

Menu t = new Menu("Transactions");
MenuItem item19, item20, item21;
t.add(item19 = new MenuItem("Insert generate"));
t.add(item20 = new MenuItem("Update generate"));
t.add(item21 = new MenuItem("Delete generate"));
mbar.add(t);


/* register listeners
item1.addActionListener(this);
item2.addActionListener(this);
item3.addActionListener(this);
item4.addActionListener(this);
item5.addActionListener(this);
item6.addActionListener(this);
item7.addActionListener(this);
item8.addActionListener(this);
item9.addActionListener(this);
item10.addActionListener(this);
item11.addActionListener(this);
item12.addActionListener(this);
item13.addActionListener(this);
item14.addActionListener(this);
item15.addActionListener(this);


// Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
});*/

//Frame properties
setTitle("Biometric Metro Rail System");
Color clr = new Color(200, 100, 150);
setBackground(clr);
setFont(new Font("SansSerif", Font.BOLD, 14));
setLayout(null);
setSize(500, 600);
setVisible(true);

 }  
 /*
 public void actionPerformed(ActionEvent ae)
 {

 String arg = ae.getActionCommand();
 if(arg.equals("Insert Users"))
 {
insu = new InsertUser();

addu.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
addu.dispose();
}
});
addu.buildGUI();
          }

else if(arg.equals("Update Users"))
{
updu = new UpdateUser();
updu.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
updu.dispose();
}
});
updu.buildGUI();
}

else if(arg.equals("Delete Users"))
{
delu = new DeleteUser();

delu.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
delu.dispose();
}
});
delu.buildGUI();
}

else if(arg.equals("Insert Videos"))
{
addv = new AddVideo();
addv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
addv.dispose();
}
});
addv.buildGUI();
}

else if(arg.equals("Update Videos"))
{
updv = new UpdateVideo();
// setVisible(false);
updv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
updv.dispose();
//setVisible(true);
}
});
updv.buildGUI();
}

else if(arg.equals("Delete Videos"))
{
delv = new DeleteVideo();
// setVisible(false);
delv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
delv.dispose();
//setVisible(true);
}
});
delv.buildGUI();
}
 
else if(arg.equals("Insert View"))
{
insv = new InsertView();
insv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
insv.dispose();
}
});
insv.buildGUI();
}
 
else if(arg.equals("Upload Video"))
{
uplv = new UploadVideo();
uplv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
uplv.dispose();
}
});
uplv.buildGUI();
}
 */
 public static void main(String ... args)
 {
new BiometricMetroRailSystem();  
 }
}