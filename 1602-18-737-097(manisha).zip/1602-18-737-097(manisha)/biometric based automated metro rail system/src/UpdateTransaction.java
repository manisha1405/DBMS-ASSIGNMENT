import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateTransaction extends Frame 
{
	Button updateTransactionButton;
	List transactionIDList;
	TextField tidText, amtdText, availText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateTransaction() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","manisha","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTransaction() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT TID FROM transaction");
		  while (rs.next()) 
		  {
			transactionIDList.add(rs.getString("TID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    transactionIDList = new List(10);
		loadTransaction();
		add(transactionIDList);
		
		//When a list item is selected populate the text fields
		transactionIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM transaction where TID ="+transactionIDList.getSelectedItem());
					rs.next();
					tidText.setText(rs.getString("TID"));
					amtdText.setText(rs.getString("AMOUNT_DEDUCTED"));
					availText.setText(rs.getString("AVAILABLE_BALANCE"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		updateTransactionButton = new Button("Update");
		updateTransactionButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE transaction "
					+ "SET amount_deducted='" + amtdText.getText() + "', "
					+ "available_balance=" + availText.getText() + " WHERE tid = "
					+ transactionIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					transactionIDList.removeAll();
					loadTransaction();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		tidText = new TextField(15);
		tidText.setEditable(false);
		amtdText = new TextField(15);
		availText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Transaction ID:"));
		first.add(tidText);
		first.add(new Label("Amount Deducted:"));
		first.add(amtdText);
		first.add(new Label("Available Balance:"));
		first.add(availText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateTransactionButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("UPDATE TRANSACTION");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateTransaction upt = new UpdateTransaction();

		upt.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upt.buildGUI();
	}
}
