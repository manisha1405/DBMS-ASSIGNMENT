import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.*;
import java.awt.*;

import java.sql.*;

public class InsertPassenger extends Frame
{
Button adduserbtn;
TextField usidtxt, mailtxt, pnametxt, contacttxt;
TextArea errtxt;
Connection connection;
Statement statement;
public InsertPassenger()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","manisha","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

public void buildGUI()
{

adduserbtn = new Button("Enter");
adduserbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
 
 String query= "INSERT INTO passengers VALUES(" + usidtxt.getText() + ", " + "'" + mailtxt.getText() + "'"+"," +"'"+ pnametxt.getText() +"'"+ "," + contacttxt.getText() + ")";
 int i = statement.executeUpdate(query);
//  System.out.print("jgig\nbj");
 errtxt.append("\nInserted " + i + " rows successfully");
//  System.out.print("jgig\nbj");
}
catch (SQLException insertException)
{
 displaySQLErrors(insertException);
}
}
});


usidtxt = new TextField(15);
mailtxt = new TextField(15);
pnametxt = new TextField(15);
contacttxt = new TextField(15);


errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("Passenger ID:"));
first.add(usidtxt);
first.add(new Label("mail id:"));
first.add(mailtxt);
first.add(new Label("Passenge name:"));
first.add(pnametxt);
first.add(new Label("contact number:"));
first.add(contacttxt);
first.setBounds(125,90,200,100);

Panel second = new Panel(new GridLayout(4, 1));
second.add(adduserbtn);
        second.setBounds(125,220,150,100);        

Panel third = new Panel();
third.add(errtxt);
third.setBounds(125,320,300,200);

setLayout(null);

add(first);
add(second);
add(third);
   
setTitle("INSERT PASSENGER");
setSize(500, 600);
setVisible(true);


}

private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}

public static void main(String[] args)
{
InsertPassenger user = new InsertPassenger();

user.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

user.buildGUI();

}
}
