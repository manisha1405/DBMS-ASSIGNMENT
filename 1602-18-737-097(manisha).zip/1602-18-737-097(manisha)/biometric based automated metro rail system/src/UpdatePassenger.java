import java.awt.*;

//import javax.swing.*;

import java.awt.event.*;
import java.sql.*;
public class UpdatePassenger extends Frame
{
Button upduserbtn;
List USIDList;
TextField usidtxt, mailtxt, pnametxt, contacttxt;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public UpdatePassenger()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","manisha","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
     }
private void loadUsers()
{  
try
{
 rs = statement.executeQuery("SELECT PID FROM passengers");
 while (rs.next())
 {
USIDList.add(rs.getString("PID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}
}


public void buildGUI()
{
   USIDList = new List(10);
loadUsers();
add(USIDList);

//When a list item is selected populate the text fields
USIDList.addItemListener(new ItemListener()
{
public void itemStateChanged(ItemEvent e)
{
try
{
rs = statement.executeQuery("SELECT * FROM passengers where PID ="+USIDList.getSelectedItem());
rs.next();
usidtxt.setText(rs.getString("PID"));
mailtxt.setText(rs.getString("MAIL_ID"));
pnametxt.setText(rs.getString("PNAME"));
contacttxt.setText(rs.getString("CONTACT_NUMBER"));

}
catch (SQLException selectException)
{
displaySQLErrors(selectException);
}
}
});

   
//Handle Update Sailor Button
upduserbtn = new Button("Update ");
upduserbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
Statement statement = connection.createStatement();
int i = statement.executeUpdate("UPDATE passengers "
+ "SET mail_id='" + mailtxt.getText() + "', "
+ "pname='" + pnametxt.getText() + "' , "
+ "contact_number ="+ contacttxt.getText() + " WHERE pid = "
+ USIDList.getSelectedItem());
errtxt.append("\nUpdated " + i + " rows successfully");
USIDList.removeAll();
loadUsers();
}
catch (SQLException insertException)
{
displaySQLErrors(insertException);
}
}
});

usidtxt = new TextField(15);
usidtxt.setEditable(false);
mailtxt = new TextField(15);
pnametxt = new TextField(15);
contacttxt = new TextField(15);

errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("Passenger ID:"));
first.add(usidtxt);
first.add(new Label("mail id:"));
first.add(mailtxt);
first.add(new Label("name"));
first.add(pnametxt);
first.add(new Label("contact number:"));
first.add(contacttxt);

Panel second = new Panel(new GridLayout(4, 1));
second.add(upduserbtn);

Panel third = new Panel();
third.add(errtxt);

add(first);
add(second);
add(third);
   
setTitle("UPDATE PASSENGER");
setSize(500, 600);
setLayout(new FlowLayout());
setVisible(true);

}



private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}

public static void main(String[] args)
{
UpdatePassenger upu = new UpdatePassenger();

upu.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

upu.buildGUI();
}
}