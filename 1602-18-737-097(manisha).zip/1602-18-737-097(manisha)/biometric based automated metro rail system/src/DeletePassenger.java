import java.awt.*;
 
import java.awt.event.*;
import java.sql.*;
public class DeletePassenger extends Frame
{
Button dltuserbtn;
List USIDList;
TextField usidtxt, mailtxt, pnametxt, contacttxt;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public DeletePassenger()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","manisha","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

private void loadUsers()
{  
try
{
 rs = statement.executeQuery("SELECT * FROM passengers");
 while (rs.next())
 {
USIDList.add(rs.getString("PID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}
}


public void buildGUI()
{
   USIDList = new List(10);
loadUsers();
add(USIDList);

//When a list item is selected populate the text fields
USIDList.addItemListener(new ItemListener()
{
public void itemStateChanged(ItemEvent e)
{
try
{
rs = statement.executeQuery("SELECT * FROM passengers");
while (rs.next())
{
if (rs.getString("PID").equals(USIDList.getSelectedItem()))
break;
}
if (!rs.isAfterLast())
{
usidtxt.setText(rs.getString("PID"));
mailtxt.setText(rs.getString("MAIL_ID"));
pnametxt.setText(rs.getString("PNAME"));
contacttxt.setText(rs.getString("CONTACT_NUMBER"));
}
}
catch (SQLException selectException)
{
displaySQLErrors(selectException);
}
}
});

   
//Handle Delete Sailor Button
dltuserbtn = new Button("Delete");
dltuserbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
Statement statement = connection.createStatement();
int i = statement.executeUpdate("DELETE FROM passengers WHERE PID = "
+ USIDList.getSelectedItem());
errtxt.append("\nDeleted " + i + " rows successfully");
usidtxt.setText(null);
mailtxt.setText(null);
pnametxt.setText(null);
contacttxt.setText(null);
USIDList.removeAll();
loadUsers();
}
catch (SQLException insertException)
{
displaySQLErrors(insertException);
}
}
});

usidtxt = new TextField(15);
mailtxt = new TextField(15);
pnametxt = new TextField(15);
contacttxt = new TextField(15);

errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("Passenger ID:"));
first.add(usidtxt);
first.add(new Label("Mail Id:"));
first.add(mailtxt);
first.add(new Label("Passenger name:"));
first.add(pnametxt);
first.add(new Label("contact number:"));
first.add(contacttxt);

Panel second = new Panel(new GridLayout(4, 1));
second.add(dltuserbtn);

Panel third = new Panel();
third.add(errtxt);

add(first);
add(second);
add(third);
   
setTitle("DELETE PASSENGER");
setSize(450, 600);
setLayout(new FlowLayout());
setVisible(true);

}





private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}



public static void main(String[] args)
{
DeletePassenger delu = new DeletePassenger();

delu.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

delu.buildGUI();
}
}